# Strip Collage — Guide d'utilisation

> **Version 2** · Export navigateur · JPG · WebP · PNG · AVIF (via serveur Node)

---

## Table des matières

1. [Installation](#1-installation)
2. [Démarrage rapide](#2-démarrage-rapide)
3. [Interface — Vue d'ensemble](#3-interface--vue-densemble)
4. [Workflow étape par étape](#4-workflow-étape-par-étape)
5. [Marques et dimensions](#5-marques-et-dimensions)
6. [Paramètres des strips](#6-paramètres-des-strips)
7. [Color Burn+](#7-color-burn)
8. [Export](#8-export)
9. [Sauvegarde sur serveur](#9-sauvegarde-sur-serveur)
10. [Configurations](#10-configurations)
11. [Personnalisation JSON](#11-personnalisation-json)
12. [Résolution de problèmes](#12-résolution-de-problèmes)

---

## 1. Installation

### Mode standalone (sans Node.js)

Aucune installation requise.

```
1. Télécharger StripCollage_v2.html
2. Ouvrir dans Chrome, Firefox ou Safari
3. Prêt — tous les formats sauf AVIF disponibles
```

### Mode complet avec export AVIF et sauvegarde serveur

```bash
npm install          # installe sharp (encodeur AVIF)
node server.js       # démarre sur http://localhost:7842
```

Ouvrir `http://localhost:7842`. L'indicateur ⚫ passe à 🟢 automatiquement.

### Configuration du dossier de sortie

Modifier en tête de `server.js` :

```js
const EXPORT_DIR     = './exports';  // chemin absolu ou relatif
const SUBDIR_BY_DATE = true;         // sous-dossier YYYY-MM-DD automatique
const PORT           = 7842;
```

| Contexte | Valeur EXPORT_DIR |
|----------|-------------------|
| Disque réseau Windows monté en Z: | `'Z:\\projets\\strip-collage'` |
| NAS Linux monté | `'/mnt/nas/exports'` |
| Dossier local relatif | `'./exports'` |

---

## 2. Démarrage rapide

```
1. Glisser une image sur "Image source" (sidebar gauche)
2. Repositionner le cadre → "Valider le recadrage →"
3. Cocher une marque dans la barre Marques
4. Ajuster les strips si disponibles
5. Renseigner le dossier de destination (optionnel)
6. Cliquer "Exporter"
```

---

## 3. Interface — Vue d'ensemble

```
┌─ Header ──────────────────────────── Tour guidé ↗ ────────────┐
│  Strip Collage    1·Image → 2·Recadrage → 3·Composition        │
├─ Marques ─────────────────────────────────────────────────────┤
│  □ BECM  becm_   [orient.̶] [strips̶] [offsets̶] [CB+̶]            │
│  ■ CIC BP cicbp_ [orient.] [strips] [offsets] [CB+]  ▾        │
│    □ Square 800×800   ■ Portrait 800×1200   □ Paysage …        │
├─ Panel ──────────────────────┬────────────────────────────────┤
│  Sidebar                     │  Zone preview                  │
│  · Image source              │  ● Onboarding sans image       │
│  · Taille du document *      │  ● Phase crop → Valider        │
│  · Orientation *             │  ● Phase compo                 │
│  · Strips *                  │    Toggle format actuel /      │
│  · Décalages individuels *   │           tous les formats     │
│  · Color Burn+ *             │    Miniatures par dimension    │
│  · Réinitialiser             │                                │
│  (* masqué selon marque)     │                                │
├─ Export ──────────────────────────────────────────────────────┤
│  Dossier [projets/ete/{{brand}}]  Nom [visuel_{{dimensions}}]  │
│  Formats  [Exporter]  □ Sauvegarder sur serveur 🟢             │
│  Aperçu des fichiers qui seront générés                        │
├─ Job Queue ────────────────────────────────────────────────────┤
├─ Galerie ──────────────────────────────────────────────────────┤
└─ Configurations (accordéon) ──────────────────────────────────┘
```

---

## 4. Workflow étape par étape

### Étape 1 — Importer une image

- Glisser-déposer sur la zone **Image source**, ou cliquer pour parcourir
- Formats : JPEG, PNG, WebP, GIF, BMP, TIFF
- L'indicateur passe à **2 · Recadrage**

### Étape 2 — Choisir le point d'intérêt

- **Glisser** l'image pour repositionner le cadre
- Le cadre respecte le ratio des dimensions du document courant
- La **grille en tiers** aide à composer

Cliquer **"Valider le recadrage →"**.

> ↩ Cliquer **"← Recadrer"** à tout moment pour ajuster.

### Étape 3 — Composer les strips

L'image est fixe. Les strips se superposent comme des masques.

**Toggle preview :**
- `Voir format actuel` → aperçu unique en temps réel au ratio des sliders
- `Voir tous les formats` → miniatures de toutes les dimensions de la marque active

---

## 5. Marques et dimensions

### Cocher une marque

Trois effets simultanés :
1. La marque est incluse dans le **batch export**
2. La **sidebar** affiche uniquement les sections disponibles
3. Le **preview** affiche les dimensions de cette marque

### Accordéon des dimensions

Cliquer sur la ligne d'une marque pour ouvrir/fermer ses dimensions.
Les cases à cocher contrôlent quelles dimensions sont exportées.

### Badges de features

| Badge | Bleu = actif | Barré = inactif |
|-------|-------------|-----------------|
| `orient.` | Orientation + angle disponibles | Vertical fixe |
| `strips` | Paramètres strips visibles | Image pleine surface |
| `offsets` | Décalages individuels visibles | — |
| `CB+` | Color Burn disponible | — |

---

## 6. Paramètres des strips

| Paramètre | Description |
|-----------|-------------|
| **Nombre** (2–10) | Nombre de strips |
| **Hauteur %** | % de la hauteur doc (V/D) ou largeur (H) |
| **Largeur %** | % total occupé par l'ensemble des strips |
| **Gap** | Espace entre strips (px, scalé à l'export) |
| **Angle** | Inclinaison en mode Diagonal (−60° à +60°) |
| **Décalage global** | Alternance ±v/2 sur tous les strips, barycentre = 0 |

### Décalages et hauteurs individuels

- **Décalage** (−150 à +150 px) : déplace perpendiculairement aux bords
- **Hauteur** (20% à 150%) : hauteur relative à la valeur globale

---

## 7. Color Burn+

| Paramètre | Rôle |
|-----------|------|
| **Strip n°** | 0 = désactivé, 1–N = strip ciblé |
| **Couleur** | Cliquer le carré pour ouvrir le sélecteur |
| **Opacité** | Intensité de l'effet (10–100%) |

> 60–80% d'opacité donne généralement le meilleur rendu.

---

## 8. Export

### Dossier de destination

Le champ **Dossier** définit la structure côté serveur. Il accepte des sous-dossiers séparés par `/` et des variables.

```
projets/ete_2026/{{brand}}   →  projets/ete_2026/becm/
{{brand}}/{{date}}           →  becm/20260505/
social/stories               →  social/stories/
```

**Variables du dossier :**

| Variable | Résultat |
|----------|---------|
| `{{brand}}` | nom marque en minuscules (`becm`) |
| `{{date}}` | `YYYYMMDD` |
| `{{mode}}` | `vertical` / `horizontal` / `diagonal` |

Laisser vide = fichiers directement dans `EXPORT_DIR` (+ sous-dossier date si activé).

### Nom du fichier

| Variable | Exemple |
|----------|---------|
| `{{dimensions}}` | `800x1200` |
| `{{mode}}` | `vertical` |
| `{{brand}}` | `becm` |
| `{{date}}` | `20260505` |
| `{{count}}` | `3` |

**Exemple complet :**
- Dossier : `social/{{brand}}`
- Nom : `visuel_{{dimensions}}`
- Résultat : `exports/2026-05-05/social/becm/becm_visuel_800x800_hq.jpg`

### Formats

| Format | Qualité | Fond | Nécessite Node |
|--------|---------|------|----------------|
| JPG HQ | 95% | Blanc | Non |
| JPG Web | 75% | Blanc | Non |
| WebP | 90% | Transparent | Non |
| AVIF | 80% | Transparent | **Oui** |
| PNG | Lossless | Transparent | Non |

---

## 9. Sauvegarde sur serveur

Cocher **"Sauvegarder sur serveur"** pour écrire les fichiers sur le disque du serveur Node en plus du téléchargement navigateur.

**Indicateur :**
- ⚫ Serveur non démarré — sans effet (fallback silencieux)
- 🟢 Serveur connecté — fichiers écrits sur disque

**Structure sur le serveur :**

```
EXPORT_DIR/
  └── 2026-05-05/                ← SUBDIR_BY_DATE = true
        └── social/becm/         ← dossier saisi dans l'interface
              ├── becm_visuel_800x800_hq.jpg
              └── becm_visuel_800x1200_hq.jpg
```

**Routes disponibles :**

| Route | Méthode | Rôle |
|-------|---------|------|
| `/status` | GET | État + chemin d'export |
| `/save` | POST | Écrit un fichier sur disque |
| `/convert` | POST | PNG → AVIF via sharp |
| `/files` | GET | Liste récursive des exports |

> Les séquences `..` dans le chemin de dossier sont neutralisées côté serveur pour empêcher toute sortie hors de `EXPORT_DIR`.

---

## 10. Configurations

### Sauvegarder

1. Régler tous les paramètres
2. Ouvrir l'accordéon **"Configurations"**
3. Nommer le slot (ou laisser le placeholder)
4. Cliquer **Sauvegarder**

Les configs persistent en **localStorage** entre sessions.

### Boutons par slot

| Bouton | Action |
|--------|--------|
| **Sauvegarder** | Enregistre l'état courant dans ce slot |
| **Preview** | Charge la config dans les sliders sans changer le slot actif |
| **Charger** | Charge et marque ce slot comme actif |
| **Vider** | Efface le slot (confirmation requise) |

### Export / Import JSON

- **↓ JSON** — télécharge toutes les configs dans un fichier horodaté
- **↑ JSON** — importe depuis un fichier JSON (format vérifié)

---

## 11. Personnalisation JSON

### Ajouter une marque

```js
{
  name    : 'Ma Marque',
  prefix  : 'mm_',
  checked : false,
  preview : false,
  features: {
    docSize     : false,  // dimensions fixées par JSON (slider masqué)
    orientation : true,
    strips      : true,
    offsets     : false,
    colorBurn   : true
  },
  dimensions: [
    { label: 'Square',   w: 800,  h: 800,  checked: true  },
    { label: 'Story',    w: 1080, h: 1920, checked: false },
    { label: 'Bannière', w: 1200, h: 628,  checked: false }
  ]
}
```

### Modifier les slots de configuration

```js
configs: {
  slots : 8,
  cols  : 4,
  names : ['A','B','C','D','E','F','G','H']
}
```

### Changer le port

Dans `server.js` : `const PORT = 7842;`
Dans le HTML : `var AVIF_SERVER = 'http://localhost:7842';`

---

## 12. Résolution de problèmes

| Problème | Solution |
|----------|----------|
| Indicateur ⚫ (AVIF / serveur) | Vérifier que `node server.js` est lancé. Tester `http://localhost:7842/status`. |
| Export ne démarre pas | Cocher au moins une marque, une dimension et un format. |
| Preview vide | Cliquer "Valider le recadrage →" après import. |
| Strips absents | Vérifier que la marque a `strips: true`. |
| Fichiers non écrits sur disque | "Sauvegarder sur serveur" coché + indicateur 🟢. |
| Dossier non créé | `node server.js` doit avoir les droits d'écriture sur `EXPORT_DIR`. |
| Configs perdues | En navigation privée, localStorage ne persiste pas. Exporter en JSON. |
| Téléchargements bloqués | Autoriser les téléchargements multiples dans les paramètres du navigateur. |
| `npm install` échoue | Vérifier Node.js ≥ 18 : `node --version`. |

---

*Strip Collage v2 — Export navigateur multi-formats*
