# Strip Collage v2

Outil de composition visuelle — export multi-formats, multi-marques, batch.

## Démarrage rapide

```bash
npm install        # installe sharp (AVIF)
node server.js     # démarre sur http://localhost:7842
```

Ou ouvrir `index.html` directement dans un navigateur (sans Node — AVIF désactivé).

## Configuration

Modifier en tête de `server.js` :

```js
const EXPORT_DIR     = './exports';   // dossier de sortie
const SUBDIR_BY_DATE = true;          // sous-dossier YYYY-MM-DD
const PORT           = 7842;
```

Voir `GUIDE.md` pour la documentation complète.
